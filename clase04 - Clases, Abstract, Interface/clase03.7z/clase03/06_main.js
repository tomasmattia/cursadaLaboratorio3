"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _01_clases_1 = require("./01_clases");
var a1 = new _01_clases_1.Auto("ROJO", 120500);
console.log(a1.color);
console.log(a1.GetPrecio());
_01_clases_1.Auto.MetodoEstatico();
console.log("fin...!!");
//# sourceMappingURL=06_main.js.map