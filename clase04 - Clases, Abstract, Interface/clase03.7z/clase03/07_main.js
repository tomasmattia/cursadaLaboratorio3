"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//import {Vehiculo} from "./02_herencia";
var _02_herencia_1 = require("./02_herencia");
var a1 = new _02_herencia_1.Auto("MARRON", 523000, "RENAULT");
console.log(a1.Mostrar());
//# sourceMappingURL=07_main.js.map