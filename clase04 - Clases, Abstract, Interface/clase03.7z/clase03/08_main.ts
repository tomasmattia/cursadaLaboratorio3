import {Vehiculo} from "./04_claseAbstracta";
import {Auto} from "./04_claseAbstracta";


let miAuto = new Auto("NARANJA", 150, "FIAT");

console.log(miAuto.Mostrar());

miAuto.Acelerar();
