//import {Vehiculo} from "./02_herencia";
import {Auto} from "./02_herencia";

let a1 = new Auto("MARRON", 523000, "RENAULT");

console.log(a1.Mostrar());
