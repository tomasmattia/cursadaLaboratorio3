/// <reference path="./auto.ts" />

    let autito:Clases.Auto=new Clases.Auto("abc123","bmw",100);
    console.log(autito.ToJson());
    console.log(autito.GetPrecioConIva());
