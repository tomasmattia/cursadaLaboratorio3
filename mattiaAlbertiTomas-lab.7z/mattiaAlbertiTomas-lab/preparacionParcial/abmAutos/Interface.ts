namespace Interfaces {

    export interface Itributable {

        GetPrecioConIVA() : number;

    }

}