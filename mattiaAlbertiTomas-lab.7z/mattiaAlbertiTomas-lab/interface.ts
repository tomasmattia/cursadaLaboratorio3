namespace Interfaces
{
    export interface ITributable
    {
        GetPrecioConIva():number;
    }
}
   